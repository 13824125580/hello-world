/*
** $Id: template.h 7363 2007-08-16 05:11:52Z xgwang $
**
** template.h: the template header file.
**
** Copyright (C) 2003 ~ 2007 Feynman Software.
**
*/

#ifndef GUI_XXX_H
    #define GUI_XXX_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */


#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* GUI_XXX_H */

