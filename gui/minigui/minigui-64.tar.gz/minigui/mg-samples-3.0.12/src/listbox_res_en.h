#define     deleting_the_files              "Deleting the files"
#define     directories                     "Directories:"
#define     files_                           "Files:"
#define     path_                            "Path: "
#define     delete_                         "Delete"
#define     cancel_                          "Cancel"
#define     deleting_files_                  "Deleting files"

