/*
 * animation_res_en.h
 * GB2312 charset for Simplified Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define AN_ST_CAP   "�����ؼ�"
