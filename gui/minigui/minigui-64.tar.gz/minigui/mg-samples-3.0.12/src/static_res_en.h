#define CAPTION "Demo for STATIC Control"
#define PROMPTA "Double-click me!"
#define PROMPTB "I am double-clicked. :)"
