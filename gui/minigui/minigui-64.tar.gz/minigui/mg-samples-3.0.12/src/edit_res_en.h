#define please_input_letters         "Please input letters"
#define please_input_a_letter        "Please input a letter:"
#define OK                           "OK"
