#define    version_info                "Version Info" 
#define    CPU_info                    "CPU Info"
#define    mem_info                    "Mem Info"
#define    partition_info              "Partition Info"
#define    MiniGUI_info                "MiniGUI Info"
#define    System_info                 "System Info"
#define    Refresh                     "Refresh"
#define    Close                       "Close"

