#define please_input_the_length                         "Please input the length"
#define please_input_the_length_mm                      "Please input the length (mm)"
#define equivalent_to_inches                            "Equivalent to 0.00 inches"
#define OK                                              "OK"
#define equivalent_to_f_inches                          "Equivalent to %.5f inches"

