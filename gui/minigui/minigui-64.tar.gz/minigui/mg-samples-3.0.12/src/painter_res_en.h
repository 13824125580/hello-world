#define CAPTION "Painter"
