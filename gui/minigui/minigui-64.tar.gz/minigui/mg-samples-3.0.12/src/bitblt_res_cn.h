/*
 * bitblt_res_en.h
 * GB2312 charset for Simlified Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define BB_ST_CAP   "Bitbltʾ������"
