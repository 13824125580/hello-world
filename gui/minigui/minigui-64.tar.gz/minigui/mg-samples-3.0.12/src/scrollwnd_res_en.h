#define CAPTION         "Image Viewer"
#define BUTTON_LEFT     "Zoom in"
#define BUTTON_RIGHT    "Zoom out"
