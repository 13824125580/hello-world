#define   I_will_at                                              "I will at "
#define   meet                                                   "meet"
#define   zeus_is_the_leader_of_the                              "Zeus is the leader of the gods and god of the sky and thunder in Greek mythology."
#define   OK                                                     "OK"
#define   Cancel                                                 "Cancel"
#define   meeting_plan                                           "Meeting  Plan"

char date[1024] = "Your date : You will meet %s at %d:%d";

static const char* daxia [] =
{
    "Zeus",
    "Pan",
    "Apollo",
    "Heracles",
    "Achilles",
    "Jason",
    "Theseus",
};
static const char* daxia_char [] =
{
    "Zeus is the leader of the gods and god of the sky and thunder in Greek mythology.",
    "Pan  is the Greek god who watches over shepherds and their flocks.",
    "Apollo is a god in Greek and Roman mythology, the son of Zeus and Leto, and the twin of Artemis.",
    "Heracles was the greatest of the mythical Greek heroes, best known for his superhuman strength and many stories are told of his life.",
    "Achilles was the greatest warrior in the Trojan War.",
    "Jason is a hero of Greek mythology. His father was Aeson, the rightful king of Iolcus.",
    "Theseus was a legendary king of Athens. Theseus was considered by Athenians as the great reformer.",
};

