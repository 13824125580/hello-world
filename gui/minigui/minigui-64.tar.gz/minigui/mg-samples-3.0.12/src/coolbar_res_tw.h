/*
 * coolbar_res_en.h
 * big5 charset for Complex Chinese support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define CLB_ST_CAP  "CoolBar�ҵ{"

static const char* hint[] =
{
   "�Ʀr 0", "�Ʀr 1", "�Ʀr 2", "�Ʀr 3", "�Ʀr 4", 
   "�Ʀr 5", "�Ʀr 6", "�Ʀr 7", "�Ʀr 8", "�Ʀr 9"
};
