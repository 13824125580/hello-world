#define CAPTION "Flying GUI"
