/*
 * createicon_res_en.h
 * utf-8 charset for English support.
 * wangjian<wangjian@minigui.org>
 * 2008-2-14.
 */

#define CI_ST_CAP   "Demo of creating icon"
