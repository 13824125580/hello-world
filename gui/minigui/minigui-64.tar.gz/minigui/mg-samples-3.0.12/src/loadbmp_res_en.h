#define CAPTION "Load and display a bitmap"
