#define   contents                  "Contents"   
#define   book_contents        "Book Contents"
#define   OK                          "OK"

static const char *chapter[] =
{
    "Static Control",
    "Button Control",
    "Edit Control",
    "Listbox Control",
    "Treeview Control",
};

static const char *section[] =
{
    "Styles of Control",
    "Messages of Control",
    "Sample Program"
};

