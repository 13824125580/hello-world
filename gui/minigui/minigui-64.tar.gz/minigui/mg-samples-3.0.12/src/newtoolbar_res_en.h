#define CAPTION "New Toolbar Control"
