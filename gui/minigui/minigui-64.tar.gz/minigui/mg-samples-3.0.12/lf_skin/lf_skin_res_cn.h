
static char* g_pTitleButton = "换肤" ;

static char* g_pHelpList    = "列表" ;

static char* g_pHelpInfo    = "信息" ;

static char* g_pMainTitle   = "媒体播放器" ;

static char* g_pHelpTitle   = "帮助" ;

static char* help_info_text = "该媒体播放器是以MiniGUI Versi\n"
                              "on 3.0为平台开发的应用程序\n"
                              "版权所有 2003-2008 北京飞漫软\n"
                              "件技术有限公司\n";

static TVITEMINFO ListViewInfo =
{
    "帮助" 
} ;

static const char *chapter[] = 
{
    "关于播放",
    "关于停止",
    "关于音量",
    "添加播放文件",
};

static const char *section[] =
{
    "按开始或暂停按钮",
    "按停止按钮",
    "滑动音量条",
    "按添加文件按钮"
};
