/* 
** $Id: taskbar.c 381 2008-01-28 10:19:26Z wangjian $
**
** The taskbar of MDE
**
** Copyright (c) 2001, Wei Yongming (ymwei@minigui.org)
** Copyright (C) 2003 ~ 2007 Feynman Software.
**
** Create date: 2001/09/07
*/

/*
**  This source is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public
**  License as published by the Free Software Foundation; either
**  version 2 of the License, or (at your option) any later version.
**
**  This software is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
**  General Public License for more details.
**
**  You should have received a copy of the GNU General Public
**  License along with this library; if not, write to the Free
**  Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
**  MA 02111-1307, USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>
#include <minigui/control.h>

#include "taskbar.h"

static BOOL quit = FALSE;

static char* mk_time (char* buff)
{
    time_t t;
    struct tm * tm;

    time (&t);
    tm = localtime (&t);
    sprintf (buff, "%02d:%02d:%02d", tm->tm_hour, tm->tm_min, tm->tm_sec);

    return buff;
}

APPINFO app_info;

static void free_app_info (void)
{
    int i;
    APPITEM* item;

    item = app_info.app_items;
    for (i = 0; i < app_info.nr_apps; i++, item++) {
        if (item->bmp.bmBits) {
            UnloadBitmap (&item->bmp);
            item->bmp.bmBits = NULL;
        }
    }

    free (app_info.app_items);
    app_info.app_items = NULL;
}

static void strsubchr (char* string, int c1, int c2)
{
    char* tmp;

    while (string && (tmp = strchr (string, c1))) {
        *tmp = c2;
        string = tmp;
    }
}

static BOOL get_app_info (void)
{
    int i;
    APPITEM* item;
    char section [10];

    if (GetIntValueFromEtcFile (APP_INFO_FILE, "taskbar", "nr", &app_info.nr_apps) != ETC_OK)
        return FALSE;

    if (app_info.nr_apps <= 0)
        return FALSE;

    GetIntValueFromEtcFile (APP_INFO_FILE, "taskbar", "autostart", &app_info.autostart);
    
    if (GetValueFromEtcFile (APP_INFO_FILE, "taskbar", "logo", app_info.logo_path, PATH_MAX + NAME_MAX) != ETC_OK)
        return FALSE;
           

    if (app_info.autostart >= app_info.nr_apps || app_info.autostart < 0)
        app_info.autostart = 0;

    if ((app_info.app_items = (APPITEM*)calloc (app_info.nr_apps, sizeof (APPITEM))) == NULL) {
        return FALSE;
    }

    item = app_info.app_items;
    for (i = 0; i < app_info.nr_apps; i++, item++) {

        sprintf (section, "app%d", i);
        if (GetValueFromEtcFile (APP_INFO_FILE, section, "path", item->path, PATH_MAX) != ETC_OK)
            goto error;

        if (GetValueFromEtcFile (APP_INFO_FILE, section, "name", item->name, NAME_MAX) != ETC_OK)
            goto error;

        if (GetValueFromEtcFile (APP_INFO_FILE, section, "layer", item->layer, LEN_LAYER_NAME) != ETC_OK)
            goto error;

        if (GetValueFromEtcFile (APP_INFO_FILE, section, "tip", item->tip, TIP_MAX) != ETC_OK)
            goto error;

        strsubchr (item->tip, '&', ' ');

        if (GetValueFromEtcFile (APP_INFO_FILE, section, "icon", item->bmp_path, PATH_MAX + NAME_MAX) != ETC_OK)
            goto error;

        if (LoadBitmap (HDC_SCREEN, &item->bmp, item->bmp_path) != ERR_BMP_OK)
            goto error;

        item->cdpath = TRUE;
    }
    return TRUE;

error:
    free_app_info ();
    return FALSE;
}

static HWND create_app_coolbar (HWND hWnd)
{
    int i;
    HWND hCoolBar;
    COOLBARITEMINFO bar_item;
    APPITEM* app_item;

    hCoolBar = CreateWindow (CTRL_COOLBAR, "",
                        WS_CHILD | WS_VISIBLE, _ID_APPS_COOLBAR,
                        _WIDTH_START + _MARGIN * 2, _MARGIN,
                        _WIDTH_APPS, _HEIGHT_CTRL,
                        hWnd, 0);

    bar_item.insPos = 0;
    bar_item.id = 0;
    bar_item.ItemType = TYPE_TEXTITEM;
    bar_item.Bmp = NULL;
    bar_item.ItemHint = "Quit MDE";
    bar_item.Caption = "Quit";
    bar_item.dwAddData= 0;

    SendMessage (hCoolBar, CBM_ADDITEM, 0, (LPARAM)&bar_item);

    app_item = app_info.app_items;
    for (i = 0; i < app_info.nr_apps; i++, app_item++) {
        bar_item.insPos = i + 1;
        bar_item.id = i + 1;
        bar_item.ItemType = TYPE_BMPITEM;
        bar_item.Bmp = &app_item->bmp;
        bar_item.ItemHint = app_item->tip;
        bar_item.Caption = NULL;
        bar_item.dwAddData= 0;

        SendMessage (hCoolBar, CBM_ADDITEM, 0, (LPARAM)&bar_item);
    }

    return hCoolBar;
}

static void under_construction (HWND hwnd)
{
    MessageBox (hwnd, 
            "This function is under construction.",
            "MDE!",
            MB_OK | MB_ICONEXCLAMATION);
}

static BOOL ask_for_quit (HWND hwnd)
{
    if (MessageBox (hwnd, 
            "You are asking for quit. \n\nDo you want to quit really?",
            "Do you want to quit really?",
            MB_YESNO | MB_ICONQUESTION) == IDYES) {
        quit = TRUE;
    }
}

static HWND hIMEWnd = 0;
static BITMAP * plogo = NULL;
static int TaskBarWinProc (HWND hWnd, int message, WPARAM wParam, LPARAM lParam)
{
    char buff [20];

    switch (message) {
    case MSG_CREATE:
    {
        if (!get_app_info ())
            return 1;
        plogo = calloc (1 , sizeof(BITMAP));
        LoadBitmap (HDC_SCREEN , plogo , app_info.logo_path);
/*
        CreateWindow (CTRL_BUTTON, "Start", WS_CHILD | WS_VISIBLE, _ID_START_BUTTON, 
                    _MARGIN, _MARGIN, _WIDTH_START, _HEIGHT_CTRL, hWnd, 0);
                    */
        CreateWindow (CTRL_STATIC, "", SS_REALSIZEIMAGE | SS_CENTERIMAGE | SS_BITMAP | WS_CHILD | WS_VISIBLE, _ID_START_BUTTON, 
                    _MARGIN, _MARGIN, _WIDTH_START, _HEIGHT_CTRL, hWnd, (DWORD)plogo);

        CreateWindow (CTRL_STATIC, mk_time (buff), WS_CHILD | WS_BORDER | WS_VISIBLE | SS_CENTER, 
                    _ID_TIME_STATIC, g_rcScr.right - _WIDTH_TIME - _MARGIN, _MARGIN, 
                    _WIDTH_TIME, _HEIGHT_CTRL, hWnd, 0);

        create_app_coolbar (hWnd);

#ifdef _MGTIMER_UNIT_10MS
        SetTimer (hWnd, _ID_TIMER, 100);
#else
        SetTimer (hWnd, _ID_TIMER, 10);
#endif
        break;
    }

    case MSG_COMMAND:
    {
        int code = HIWORD (wParam);
        int id   = LOWORD (wParam);
        switch (id) {
        case _ID_START_BUTTON:
            under_construction (hWnd);
            break;
        case _ID_APPS_COOLBAR:
            if (code == 0) {
                ask_for_quit (hWnd);
            }
            else
                exec_app (code - 1);
            break;
        }

        if (id == _ID_LAYER_BOX && code == 0) {
            MG_Layer* layer = (MG_Layer*) GetWindowAdditionalData ((HWND)lParam);

            if (layer) {
                ServerSetTopmostLayer (layer);
            }
        }
    }
    break;

    case MSG_TIMER:
    {
        SetDlgItemText (hWnd, _ID_TIME_STATIC, mk_time (buff));
        if (quit)
            PostMessage (hWnd, MSG_CLOSE, 0, 0);
        break;
    }
        
    case MSG_CLOSE:
        KillTimer (hWnd, _ID_TIMER);
        free (plogo);
        DestroyAllControls (hWnd);
        free_app_info ();
        DestroyMainWindow (hWnd);
        PostQuitMessage (hWnd);
        return 0;
    }

    return DefaultMainWinProc (hWnd, message, wParam, lParam);
}

HWND create_task_bar (void)
{
    MAINWINCREATE CreateInfo;
    HWND hTaskBar;

    CreateInfo.dwStyle = WS_ABSSCRPOS | WS_VISIBLE;
    CreateInfo.dwExStyle = WS_EX_TOOLWINDOW;
    CreateInfo.spCaption = "TaskBar" ;
    CreateInfo.hMenu = 0;
    CreateInfo.hCursor = GetSystemCursor (0);
    CreateInfo.hIcon = 0;
    CreateInfo.MainWindowProc = TaskBarWinProc;
    CreateInfo.lx = g_rcScr.left; 
    CreateInfo.ty = g_rcScr.bottom - HEIGHT_TASKBAR;
    CreateInfo.rx = g_rcScr.right;
    CreateInfo.by = g_rcScr.bottom;
    CreateInfo.iBkColor = GetWindowElementColor (WE_MAINC_THREED_BODY); 
    CreateInfo.dwAddData = 0;
    CreateInfo.hHosting = HWND_DESKTOP;

    hTaskBar = CreateMainWindow (&CreateInfo);

    return hTaskBar;
}

pid_t exec_app (int app)
{
    pid_t pid = 0;
    char buff [PATH_MAX + NAME_MAX + 1];

    if ((pid = vfork ()) > 0) {
        fprintf (stderr, "new child, pid: %d.\n", pid);
    }
    else if (pid == 0) {
        if (app_info.app_items [app].cdpath) {
            chdir (app_info.app_items [app].path);
        }
        strcpy (buff, app_info.app_items [app].path);
        strcat (buff, app_info.app_items [app].name);

        if (app_info.app_items [app].layer [0]) {
            execl (buff, app_info.app_items [app].name, 
                        "-layer", app_info.app_items [app].layer, NULL);
        }
        else {
            execl (buff, app_info.app_items [app].name, NULL);
        }

        perror ("execl");
        _exit (1);
    }
    else {
        perror ("vfork");
    }

    return pid;
}

