#ifndef _GVFB_OPTION_H_
#define _GVFB_OPTION_H_

/* fast mode */
#define OPT_FASTMODE      TRUE

/* show gtk cursor */
#define OPT_SHOWGTKCURSOR TRUE

/* refresh rate */
#define OPT_REFRESHRATE   30

#endif /* #ifndef _GVFB_OPTION_H_ */

